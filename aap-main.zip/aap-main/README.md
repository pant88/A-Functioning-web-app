# aap (android_app_points) - A functioning web app

video link - https://youtu.be/dTylXazvBC8

deployed web app link - https://niteshsahu75.pythonanywhere.com/

inside aap directory
# cd aap
start the server
# python manage.py runserver

![Screenshot (16)](https://user-images.githubusercontent.com/90353118/200889213-7e8c16f9-f253-424a-82a9-8f9f319a5d6e.png)
![Screenshot (17)](https://user-images.githubusercontent.com/90353118/200889244-8cd791c1-e766-428e-94c9-2a67eb5ee624.png)
![Screenshot (18)](https://user-images.githubusercontent.com/90353118/200889268-c78ec2d6-9090-4a81-9a66-7a9a7aac3fe5.png)
